// index.ts
// 获取应用实例
const app = getApp<IAppOption>()
const defaultAvatarUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'

Component({
  data: {
    corpCode: '',
    corpInfo: null as any,
    ipInfo: '',
    showCert: false,
    showKey: false
  },

  lifetimes: {
    attached() {
      this.getIpInfo();
      // 监听网络状态变化
      wx.onNetworkStatusChange((res) => {
        if (res.isConnected) {
          this.getIpInfo();
        }
      });
    }
  },

  methods: {
    onCodeInput(e: WechatMiniprogram.Input) {
      this.setData({
        corpCode: e.detail.value
      });
    },

    async searchCorpInfo() {
      if (!this.data.corpCode) {
        wx.showToast({
          title: '请输入企业识别码',
          icon: 'error'
        });
        return;
      }

      try {
        wx.showLoading({
          title: '查询中...',
          mask: true
        });

        const response = await new Promise<WechatMiniprogram.RequestSuccessCallbackResult>((resolve, reject) => {
          wx.request({
            url: 'https://corplink.isealsuite.com/api/match',
            method: 'POST',
            data: {
              code: this.data.corpCode
            },
            header: {
              'Content-Type': 'application/json'
            },
            success: (result) => {
              console.log('企业信息查询原始响应:', result);
              console.log('响应数据:', JSON.stringify(result.data, null, 2));
              resolve(result);
            },
            fail: reject
          });
        });

        if (response.statusCode === 200) {
          this.setData({
            corpInfo: response.data as any
          });
        } else {
          wx.showToast({
            title: '查询失败',
            icon: 'error'
          });
        }
      } catch (error) {
        console.error('查询失败:', error);
        wx.showToast({
          title: '查询失败',
          icon: 'error'
        });
      } finally {
        wx.hideLoading();
      }
    },

    async getIpInfo() {
      try {
        console.log('开始获取IP信息');
        const res = await new Promise<WechatMiniprogram.RequestSuccessCallbackResult>((resolve, reject) => {
          wx.request({
            url: 'https://myip.ipip.net',
            method: 'GET',
            success: (result) => {
              console.log('IP请求原始响应:', result);
              console.log('IP请求响应数据类型:', typeof result.data);
              console.log('IP请求响应数据:', result.data);
              resolve(result);
            },
            fail: reject
          });
        });

        console.log('收到IP响应:', res);
        if (res.statusCode === 200 && res.data) {
          let ipInfo = '';
          if (typeof res.data === 'string') {
            ipInfo = res.data;
          } else {
            // 如果返回的是对象，尝试获取其中的文本内容
            ipInfo = res.data.toString();
          }
          console.log('处理后的IP信息:', ipInfo);
          
          // 如果没有"当前 IP："前缀，手动添加
          if (!ipInfo.includes('当前 IP：')) {
            ipInfo = '当前 IP：' + ipInfo;
          }

          this.setData({
            ipInfo
          });
        }
      } catch (error) {
        console.error('获取IP信息失败:', error);
        this.setData({
          ipInfo: '获取失败'
        });
      }
    },

    toggleCert() {
      this.setData({
        showCert: !this.data.showCert
      });
    },

    copyCert() {
      if (this.data.corpInfo?.data?.self_signed_cert) {
        wx.setClipboardData({
          data: this.data.corpInfo.data.self_signed_cert,
          success: () => {
            wx.showToast({
              title: '证书已复制',
              icon: 'success'
            });
          }
        });
      }
    },

    copyAllInfo() {
      if (this.data.corpInfo?.data) {
        const info = Object.entries(this.data.corpInfo.data)
          .map(([key, value]) => {
            const labels: Record<string, string> = {
              name: '名称',
              zh_name: '中文名称',
              en_name: '英文名称',
              domain: '门户域名',
              enable_self_signed: '是否使用自签证',
              self_signed_cert: '自签证书内容',
              enable_public_key: '是否启用软件分发安全校验',
              public_key: '软件分发公钥',
              enable_spa: '是否启用 SPA功能',
              spa_port: 'SPA 端口',
              enable_backup_domain: '是否启用备份域名',
              backup_domain: '备份域名'
            };
            
            if (typeof value === 'boolean') {
              value = value ? '是' : '否';
            }
            
            return `${labels[key] || key}：${value || ''}`;
          })
          .join('\n');

        wx.setClipboardData({
          data: info,
          success: () => {
            wx.showToast({
              title: '已复制全部信息',
              icon: 'success'
            });
          }
        });
      }
    },

    toggleKey() {
      this.setData({
        showKey: !this.data.showKey
      });
    },

    copyKey() {
      if (this.data.corpInfo?.data?.public_key) {
        wx.setClipboardData({
          data: this.data.corpInfo.data.public_key,
          success: () => {
            wx.showToast({
              title: '公钥已复制',
              icon: 'success'
            });
          }
        });
      }
    }
  }
});
