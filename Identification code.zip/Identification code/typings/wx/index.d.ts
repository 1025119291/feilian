declare namespace WechatMiniprogram {
  interface RequestTask {
    abort: () => void;
    offHeadersReceived: (callback?: OffHeadersReceivedCallback) => void;
    onHeadersReceived: (callback: OnHeadersReceivedCallback) => void;
  }

  interface RequestOption<T extends string | IAnyObject | ArrayBuffer = string | IAnyObject | ArrayBuffer> {
    /** 开发者服务器接口地址 */
    url: string
    /** 请求的参数 */
    data?: string | IAnyObject | ArrayBuffer
    /** 设置请求的 header，header 中不能设置 Referer。
     *
     * `content-type` 默认值为 `application/json` */
    header?: IAnyObject
    /** HTTP 请求方法
     *
     * 可选值：
     * - 'OPTIONS': HTTP 请求 OPTIONS;
     * - 'GET': HTTP 请求 GET;
     * - 'HEAD': HTTP 请求 HEAD;
     * - 'POST': HTTP 请求 POST;
     * - 'PUT': HTTP 请求 PUT;
     * - 'DELETE': HTTP 请求 DELETE;
     * - 'TRACE': HTTP 请求 TRACE;
     * - 'CONNECT': HTTP 请求 CONNECT; */
    method?:
    | 'OPTIONS'
    | 'GET'
    | 'HEAD'
    | 'POST'
    | 'PUT'
    | 'DELETE'
    | 'TRACE'
    | 'CONNECT'
    /** 返回的数据格式
     *
     * 可选值：
     * - 'json': 返回的数据为 JSON，返回后会对返回的数据进行一次 JSON.parse;
     * - '其他': 不对返回的内容进行 JSON.parse; */
    dataType?: string
    /** 响应的数据类型
     *
     * 可选值：
     * - 'text': 响应的数据为文本;
     * - 'arraybuffer': 响应的数据为 ArrayBuffer; */
    responseType?: string
    /** 接口调用成功的回调函数 */
    success?: (result: RequestSuccessCallbackResult<T>) => void
    /** 接口调用失败的回调函数 */
    fail?: (res: GeneralCallbackResult) => void
    /** 接口调用结束的回调函数（调用成功、失败都会执行） */
    complete?: (res: GeneralCallbackResult) => void
  }
} 